print("hello world")
